const fs=require('fs'), sharp=require('sharp');
const NAVY='#1C2088', RED='#B4121B', GRY='#6E6E6E', LGT='#EDEDF5', TEAL='#0E6E6E', AMB='#8A6100', GREEN='#1B7A3A';
const PUR='#A54399', YEL='#FFD400', BLU='#0072BC', MANG='#00A651', FUC='#ED1C24';
const S='Noto Sans CJK JP,sans-serif';

// SNFG primitives (r = half size)
const L=(x1,y1,x2,y2)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#000" stroke-width="2"/>`;
const C=(x,y,f,r=10)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const Q=(x,y,f,r=10)=>`<rect x="${x-r}" y="${y-r}" width="${2*r}" height="${2*r}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const D=(x,y,f,r=11)=>`<polygon points="${x},${y-r} ${x+r},${y} ${x},${y+r} ${x-r},${y}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const T=(x,y,f,r=10)=>`<polygon points="${x},${y-r} ${x+r},${y+r*0.8} ${x-r},${y+r*0.8}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const tx=(x,y,t,sz,col='#222',w='normal',a='start')=>`<text x="${x}" y="${y}" font-family="${S}" font-size="${sz}" font-weight="${w}" fill="${col}" text-anchor="${a}">${t}</text>`;
const sym=(x,y,t,col,sz=16)=>`<text x="${x}" y="${y}" font-family="serif" font-size="${sz}" font-weight="bold" fill="${col}" text-anchor="middle">${t}</text>`;

// 6'-sialyllactose, reducing end at right; returns svg, anomer symbol coloured
const sl6=(x,y,an,col)=>L(x,y,x+64,y)+D(x,y,PUR)+C(x+32,y,YEL)+C(x+64,y,BLU)+sym(x+84,y+6,an,col,18);

// result strip at bottom of each panel
const strip=(x,y,now,need)=>`
<rect x="${x}" y="${y}" width="340" height="30" rx="5" fill="#FBEAEA"/>
${tx(x+12,y+21,'&#10007;',17,RED,'bold')}${tx(x+32,y+21,'現状',15,RED,'bold')}${tx(x+74,y+21,now,15,'#222')}
<rect x="${x}" y="${y+36}" width="340" height="30" rx="5" fill="#E7F2EA"/>
${tx(x+12,y+57,'&#10003;',17,GREEN,'bold')}${tx(x+32,y+57,'必要',15,GREEN,'bold')}${tx(x+74,y+57,need,15,'#222')}`;

const panel=(x,y,n,col,q,sub,body,now,need)=>`
<rect x="${x}" y="${y}" width="364" height="290" rx="10" fill="${LGT}"/>
<circle cx="${x+26}" cy="${y+28}" r="15" fill="${col}"/>${tx(x+26,y+34,n,17,'white','bold','middle')}
${tx(x+50,y+26,q,17,'#222','bold')}
${tx(x+50,y+46,sub,14,col)}
<g transform="translate(${x},${y})">${body}</g>
${strip(x+12,y+212,now,need)}`;

// ---- panel bodies (coordinates relative to panel origin) ----
const b1=`
<path d="M70 82 L70 72 L288 72 L288 82" stroke="${GRY}" stroke-width="2" fill="none"/>
${tx(179,66,'同じ糖鎖の二通りの書き方',13,GRY,'normal','middle')}
${sl6(40,118,'&#946;',NAVY)}${sl6(216,118,'&#945;',RED)}
${tx(72,154,'G28868ZC',14,NAVY,'bold','middle')}${tx(248,154,'G63717BV',14,RED,'bold','middle')}
${tx(72,174,'12件',15,'#222','normal','middle')}${tx(248,174,'0件',15,RED,'bold','middle')}`;

const b2=`
${sl6(130,92,'?',TEAL)}${tx(182,72,'G09675VB ― 環構造が未指定',13,TEAL,'normal','middle')}
<path d="M194 106 L194 120 M110 120 L278 120 M110 120 L110 132 M278 120 L278 132" stroke="${TEAL}" stroke-width="2" fill="none"/>
${sl6(56,152,'&#945;',GRY)}${sl6(226,152,'&#946;',GRY)}
${tx(110,184,'0',15,'#222','normal','middle')}${tx(278,184,'12',15,'#222','normal','middle')}
${tx(194,200,'それが表す特定の形',13,GRY,'normal','middle')}`;

const b3=`
<rect x="24" y="74" width="142" height="100" rx="8" fill="#FFF7E0" stroke="${AMB}" stroke-width="2.5" stroke-dasharray="6,4"/>
${tx(95,94,'sialyl Lewis x',14,AMB,'bold','middle')}
${L(46,126,84,126)}${L(84,126,128,126)}${L(128,126,128,154)}
${D(46,126,PUR)}${C(84,126,YEL)}${Q(128,126,BLU)}${T(128,156,FUC,9)}
${L(128,126,206,126)}${C(206,126,MANG)}${L(206,126,250,126)}${Q(250,126,BLU)}${L(250,126,294,126)}${Q(294,126,BLU)}
${tx(250,160,'N型糖鎖の残りの部分',13,GRY,'normal','middle')}
${tx(182,194,'エピトープはより大きな構造の一部',13,GRY,'normal','middle')}`;

const b4=`
${tx(40,74,'RCSB経由',14,NAVY,'bold','start')}${tx(40,92,'10件',14,NAVY,'normal','start')}
${tx(324,74,'GlyGen経由',14,RED,'bold','end')}${tx(324,92,'5件',14,RED,'normal','end')}
<circle cx="150" cy="134" r="52" fill="${NAVY}" fill-opacity="0.13" stroke="${NAVY}" stroke-width="2.5"/>
<circle cx="214" cy="134" r="42" fill="${RED}" fill-opacity="0.12" stroke="${RED}" stroke-width="2.5"/>
${tx(128,143,'7',26,NAVY,'bold','middle')}
${tx(186,141,'3',22,'#222','bold','middle')}
${tx(236,143,'2',26,RED,'bold','middle')}
${tx(182,200,'RCSBのみ 7件 ・ 両方 3件 ・ GlyGenのみ 2件',12,GRY,'normal','middle')}`;

const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 676">
<rect width="760" height="676" fill="white"/>
${tx(14,26,'正しい識別子でもデータを取りこぼす四つの型',20,NAVY,'bold')}
${tx(14,48,'各パネル：関係する構造、現在の検索結果、本来必要な操作',14,GRY)}
${panel(8,66,'1',NAVY,'「&#945;も&#946;も同じように知りたい」','同等に有効な二つの形',b1,
  '&#945;のアクセッションは0件','両方を検索して統合 &#8594; 12件')}
${panel(388,66,'2',TEAL,'「その部分は決めていない」','より特異性の低い形',b2,
  '未指定の形は0件','特定の形へ展開 &#8594; 12件')}
${panel(8,370,'3',AMB,'「このエピトープを持つ糖鎖すべて」','全体の中の一部',b3,
  'エピトープについて糖タンパク質0件','それを含む構造を探す')}
${panel(388,370,'4',RED,'「どちらの答えが正しいのか？」','二つの資源で答えが異なる',b4,
  '経路によって10件または5件','両方を突き合わせる &#8594; 12件')}
</svg>`;
fs.writeFileSync('fig_dirs_ja.svg',svg);
sharp(Buffer.from(svg),{density:420}).resize(1800,null,{fit:'inside'}).png().toFile('fig_dirs_ja.png')
 .then(i=>console.log('fig_dirs_ja.png',i.width+'x'+i.height));
