const fs=require('fs'), sharp=require('sharp');
const NAVY='#1C2088', RED='#B4121B', GRY='#6E6E6E', LGT='#EDEDF5', TEAL='#0E6E6E', AMB='#8A6100';
const PUR='#A54399', YEL='#FFD400', BLU='#0072BC', GRN='#00A651';
const SANS='Noto Sans CJK JP,sans-serif', MONO='DejaVu Sans Mono,Menlo,monospace';
const out=(n,svg,w)=>{require('fs').writeFileSync(n.replace(/\.png$/,'.svg'),svg);return sharp(Buffer.from(svg),{density:420}).resize(w,null,{fit:'inside'}).png().toFile(n).then(i=>console.log(n,i.width+'x'+i.height));};

// SNFG trisaccharide: Neu5Ac(a2-L)Gal(b1-4)Glc  drawn right-to-left (reducing end right)
const tri=(x,y,s,anom,link,hi)=>`<g transform="translate(${x},${y}) scale(${s})">
 <line x1="104" y1="0" x2="0" y2="0" stroke="#000" stroke-width="2.4"/>
 <circle cx="104" cy="0" r="13" fill="${BLU}" stroke="#000" stroke-width="2.4"/>
 <circle cx="52" cy="0" r="13" fill="${YEL}" stroke="#000" stroke-width="2.4"/>
 <polygon points="0,-13 13,0 0,13 -13,0" fill="${PUR}" stroke="#000" stroke-width="2.4"/>
 <text x="26" y="26" font-family="serif" font-size="16" text-anchor="middle">&#945;${link}</text>
 <text x="78" y="26" font-family="serif" font-size="16" text-anchor="middle">&#946;4</text>
 ${hi?`<circle cx="104" cy="0" r="22" fill="none" stroke="${hi}" stroke-width="3" stroke-dasharray="4,3"/>`:''}
 <text x="131" y="7" font-family="serif" font-size="23" font-weight="bold" fill="${hi||'#000'}">${anom}</text></g>`;

// ---------- FIG 1 : one name, two structures ----------
const F1=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 316">
<rect width="700" height="316" fill="white"/>
<rect x="196" y="6" width="308" height="46" rx="8" fill="white" stroke="${NAVY}" stroke-width="2.5"/>
<text x="350" y="36" font-family="${SANS}" font-size="23" font-weight="bold" fill="${NAVY}" text-anchor="middle">「6&#8242;-シアリルラクトース」</text>
<text x="350" y="72" font-family="${SANS}" font-size="16" fill="${GRY}" text-anchor="middle">名前は還元末端について何も述べない</text>
<path d="M350 80 L350 96 L172 96 L172 116" stroke="${GRY}" stroke-width="2.5" fill="none"/>
<path d="M350 80 L350 96 L528 96 L528 116" stroke="${GRY}" stroke-width="2.5" fill="none"/>
<polygon points="164,114 180,114 172,130" fill="${GRY}"/><polygon points="520,114 536,114 528,130" fill="${GRY}"/>
<rect x="20" y="140" width="304" height="148" rx="8" fill="${LGT}"/>
<rect x="376" y="140" width="304" height="148" rx="8" fill="#FBECEC"/>
${tri(96,188,1.05,'&#946;','6',NAVY)}
${tri(452,188,1.05,'&#945;','6',RED)}
<text x="172" y="244" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}" text-anchor="middle">G28868ZC</text>
<text x="528" y="244" font-family="${SANS}" font-size="20" font-weight="bold" fill="${RED}" text-anchor="middle">G63717BV</text>
<text x="172" y="266" font-family="${SANS}" font-size="17" fill="#222" text-anchor="middle">PDBエントリー 12件</text>
<text x="528" y="266" font-family="${SANS}" font-size="17" font-weight="bold" fill="${RED}" text-anchor="middle">PDBエントリー 0件</text>
<text x="172" y="283" font-family="${MONO}" font-size="11" fill="${GRY}" text-anchor="middle">[a2122h-1b_1-5]&#8230;</text>
<text x="528" y="283" font-family="${MONO}" font-size="11" fill="${GRY}" text-anchor="middle">[a2122h-1a_1-5]&#8230;</text>
<text x="350" y="308" font-family="${SANS}" font-size="13" fill="${GRY}" text-anchor="middle">どちらもGlyTouCanの有効な登録。溶液中では両者は相互変換する</text>
</svg>`;

// ---------- FIG 2 : why a search returns nothing ----------
const F2=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 740 338">
<rect width="740" height="338" fill="white"/>
<text x="18" y="26" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}">検索結果が空になる理由</text>
<rect x="18" y="38" width="704" height="80" rx="8" fill="white" stroke="${NAVY}" stroke-width="2.5"/>
<text x="34" y="60" font-family="${SANS}" font-size="15" fill="${GRY}">検索する構造</text>
${tri(150,84,0.95,'&#945;','6',RED)}
<text x="470" y="80" font-family="${SANS}" font-size="16" fill="#222">還元末端が &#945;</text>
<text x="470" y="104" font-family="${MONO}" font-size="12" fill="${GRY}">&#8230;[a2122h-1a_1-5]&#8230;</text>
<text x="386" y="142" font-family="${SANS}" font-size="15" fill="${GRY}" text-anchor="start">最後の記号まで、すべてが一致する必要がある</text>
<line x1="370" y1="118" x2="370" y2="150" stroke="${GRY}" stroke-width="2" stroke-dasharray="5,4"/>
<polygon points="362,148 378,148 370,162" fill="${GRY}"/>
${[0,1].map(k=>{const y=172+k*62; return `
<rect x="18" y="${y}" width="704" height="54" rx="7" fill="${LGT}"/>
${tri(150,y+28,0.95,'&#946;','6',NAVY)}
<text x="430" y="${y+26}" font-family="${SANS}" font-size="16" fill="#222">還元末端が &#946;</text>
<text x="430" y="${y+46}" font-family="${MONO}" font-size="12" fill="${GRY}">&#8230;[a2122h-1b_1-5]&#8230;</text>
<text x="700" y="${y+34}" font-family="${SANS}" font-size="18" font-weight="bold" fill="${RED}" text-anchor="end">不一致</text>`}).join('')}
<text x="18" y="310" font-family="${SANS}" font-size="20" font-weight="bold" fill="${RED}">結果：0件 ― エラーではなく「答え」として返される</text>
<text x="18" y="330" font-family="${SANS}" font-size="13" fill="${GRY}">クエリは文字列として比較され、展開も推論も行われない</text>
</svg>`;

// ---------- FIG 3 : coverage of the 48 ----------
const F3=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 740 330">
<rect width="740" height="330" fill="white"/>
<text x="18" y="26" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}">3&#8242;-シアリルラクトース：各アクセッションが見つけるもの</text>
<text x="18" y="50" font-family="${SANS}" font-size="16" fill="#222">この三糖を含むPDBエントリーは48件</text>
<rect x="18" y="62" width="704" height="24" rx="4" fill="#E4E4EA"/>
<text x="714" y="79" font-family="${SANS}" font-size="15" fill="${GRY}" text-anchor="end">全48件</text>
<rect x="18" y="104" width="${704*19/48}" height="36" rx="4" fill="${NAVY}"/>
<text x="32" y="128" font-family="${SANS}" font-size="18" font-weight="bold" fill="white">19件</text>
<text x="${18+704*19/48+14}" y="122" font-family="${SANS}" font-size="16" fill="#222">&#945;体で検索 ― G92323ZH</text>
<text x="${18+704*19/48+14}" y="138" font-family="${SANS}" font-size="12" fill="${GRY}">29件はこの検索からは見えない</text>
<rect x="${18+704*18/48}" y="152" width="${704*30/48}" height="36" rx="4" fill="${TEAL}"/>
<text x="${18+704*18/48+14}" y="176" font-family="${SANS}" font-size="18" font-weight="bold" fill="white">30件</text>
<text x="${18+704*18/48-14}" y="170" font-family="${SANS}" font-size="16" fill="#222" text-anchor="end">&#946;体</text>
<text x="${18+704*18/48-14}" y="186" font-family="${SANS}" font-size="16" fill="#222" text-anchor="end">G91237TK</text>
<rect x="${18+704*18/48}" y="104" width="${704/48}" height="84" fill="none" stroke="${AMB}" stroke-width="2.5"/>
<text x="${18+704*18.5/48}" y="204" font-family="${SANS}" font-size="13" fill="${AMB}" text-anchor="middle">1件は両方を含む</text>
<rect x="18" y="226" width="704" height="38" rx="5" fill="none" stroke="${RED}" stroke-width="2.5" stroke-dasharray="7,5"/>
<text x="370" y="251" font-family="${SANS}" font-size="17" fill="${RED}" text-anchor="middle">単一のアクセッションでは全体を網羅できない</text>
<text x="18" y="294" font-family="${SANS}" font-size="19" font-weight="bold" fill="#222">19 + 30 &#8722; 1 = 48 ― 2回検索して統合した場合のみ</text>
<text x="18" y="316" font-family="${SANS}" font-size="13" fill="${GRY}">どちらのアクセッションも誤りではない。指定した構造については、それぞれ完全である</text>
</svg>`;


(async()=>{ await out('fig_name_ja.png',F1,1600); await out('fig_exact_ja.png',F2,1700); await out('fig_venn_ja.png',F3,1700); })();
