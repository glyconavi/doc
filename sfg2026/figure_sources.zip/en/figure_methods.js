const fs=require('fs'), sharp=require('sharp');
const NAVY='#1C2088', TEAL='#0E6E6E', GRY='#6E6E6E', LGT='#EDEDF5', AMB='#8A6100';
const PUR='#A54399', YEL='#FFD400', BLU='#0072BC';
const S='Helvetica,Arial,sans-serif', MONO='DejaVu Sans Mono,Menlo,monospace';
const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 700">
<rect width="600" height="700" fill="white"/>

<!-- step 1 : the researcher asks -->
<circle cx="52" cy="34" r="19" fill="${NAVY}"/>
<path d="M52 57 q-25 4 -25 29 h50 q0 -25 -25 -29z" fill="${NAVY}"/>
<rect x="104" y="10" width="484" height="76" rx="14" fill="white" stroke="${NAVY}" stroke-width="3"/>
<text x="124" y="40" font-family="${S}" font-size="22" fill="#222">&#8220;Which deposited structures</text>
<text x="124" y="68" font-family="${S}" font-size="22" fill="#222">contain this glycan?&#8221;</text>
<polygon points="114,66 100,88 142,78" fill="white" stroke="${NAVY}" stroke-width="3"/>
<text x="20" y="112" font-family="${S}" font-size="15" fill="${GRY}">a question in ordinary words</text>

<line x1="300" y1="118" x2="300" y2="144" stroke="${NAVY}" stroke-width="4"/>
<polygon points="290,142 310,142 300,160" fill="${NAVY}"/>

<!-- step 2 : the structure is drawn and given an identifier -->
<rect x="12" y="168" width="576" height="130" rx="10" fill="${LGT}"/>
<text x="32" y="196" font-family="${S}" font-size="20" font-weight="bold" fill="${NAVY}">The glycan is drawn, then given an identifier</text>
<g transform="translate(74,244) scale(1.0)">
 <line x1="104" y1="0" x2="0" y2="0" stroke="#000" stroke-width="2.4"/>
 <circle cx="104" cy="0" r="13" fill="${BLU}" stroke="#000" stroke-width="2.4"/>
 <circle cx="52" cy="0" r="13" fill="${YEL}" stroke="#000" stroke-width="2.4"/>
 <polygon points="0,-13 13,0 0,13 -13,0" fill="${PUR}" stroke="#000" stroke-width="2.4"/>
 <text x="26" y="26" font-family="serif" font-size="16" text-anchor="middle">&#945;6</text>
 <text x="78" y="26" font-family="serif" font-size="16" text-anchor="middle">&#946;4</text>
 <text x="128" y="7" font-family="serif" font-size="22" font-weight="bold">&#946;</text></g>
<text x="230" y="238" font-family="${S}" font-size="18" fill="#222">&#8594;</text>
<text x="258" y="238" font-family="${MONO}" font-size="13" fill="${GRY}">WURCS=2.0/3,3,2/&#8230;</text>
<text x="230" y="266" font-family="${S}" font-size="18" fill="#222">&#8594;</text>
<text x="258" y="266" font-family="${S}" font-size="19" font-weight="bold" fill="${NAVY}">G28868ZC</text>
<text x="400" y="266" font-family="${S}" font-size="14" fill="${GRY}">the identifier every</text>
<text x="400" y="284" font-family="${S}" font-size="14" fill="${GRY}">resource quotes</text>

<line x1="300" y1="300" x2="300" y2="326" stroke="${TEAL}" stroke-width="4"/>
<polygon points="290,324 310,324 300,342" fill="${TEAL}"/>

<!-- step 3 : tools are called -->
<rect x="12" y="350" width="576" height="126" rx="10" fill="${TEAL}"/>
<text x="32" y="380" font-family="${S}" font-size="20" font-weight="bold" fill="white">Software calls each resource in turn</text>
<text x="32" y="410" font-family="${S}" font-size="17" fill="#CFE6E6">build and edit the structure &#183; look up the identifier</text>
<text x="32" y="436" font-family="${S}" font-size="17" fill="#CFE6E6">query each database &#183; collect what comes back</text>
<text x="32" y="464" font-family="${S}" font-size="13" fill="#A8D4D4">GlycanBuilder-MCP &#183; GlycoNAVI-MCP &#183; TogoMCP, invoked over the Model Context Protocol</text>

<line x1="300" y1="478" x2="300" y2="504" stroke="${GRY}" stroke-width="4"/>
<polygon points="290,502 310,502 300,520" fill="${GRY}"/>

<!-- step 4 : answers -->
<rect x="12" y="528" width="576" height="104" rx="10" fill="white" stroke="${GRY}" stroke-width="2"/>
<text x="32" y="558" font-family="${S}" font-size="20" font-weight="bold" fill="#222">What comes back</text>
<text x="32" y="586" font-family="${S}" font-size="17" fill="#222">deposited structures &#183; glycoproteins &#183; diseases &#183; literature</text>
<text x="32" y="612" font-family="${S}" font-size="14" fill="${GRY}">PDB &#183; GlyCosmos &#183; UniProt &#183; GlyGen &#183; Reactome &#183; ChEMBL &#183; PubMed</text>

<rect x="12" y="648" width="576" height="42" rx="8" fill="${NAVY}"/>
<text x="300" y="666" font-family="${S}" font-size="16" font-weight="bold" fill="white" text-anchor="middle">The language model reads the question and picks the tools.</text>
<text x="300" y="683" font-family="${S}" font-size="16" font-weight="bold" fill="white" text-anchor="middle">It never writes the structure or the identifier itself.</text>
</svg>`;
fs.writeFileSync('arch.svg',svg);
sharp(Buffer.from(svg),{density:420}).resize(1500,null,{fit:'inside'}).png().toFile('arch.png')
 .then(i=>console.log('arch.png',i.width+'x'+i.height));
