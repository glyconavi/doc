const fs=require('fs'), sharp=require('sharp');
const NAVY='#1C2088', RED='#B4121B', GRY='#6E6E6E', LGT='#EDEDF5', TEAL='#0E6E6E', AMB='#8A6100', GREEN='#1B7A3A';
const PUR='#A54399', YEL='#FFD400', BLU='#0072BC', MANG='#00A651', FUC='#ED1C24';
const S='Helvetica,Arial,sans-serif';

// SNFG primitives (r = half size)
const L=(x1,y1,x2,y2)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#000" stroke-width="2"/>`;
const C=(x,y,f,r=10)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const Q=(x,y,f,r=10)=>`<rect x="${x-r}" y="${y-r}" width="${2*r}" height="${2*r}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const D=(x,y,f,r=11)=>`<polygon points="${x},${y-r} ${x+r},${y} ${x},${y+r} ${x-r},${y}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const T=(x,y,f,r=10)=>`<polygon points="${x},${y-r} ${x+r},${y+r*0.8} ${x-r},${y+r*0.8}" fill="${f}" stroke="#000" stroke-width="2"/>`;
const tx=(x,y,t,sz,col='#222',w='normal',a='start')=>`<text x="${x}" y="${y}" font-family="${S}" font-size="${sz}" font-weight="${w}" fill="${col}" text-anchor="${a}">${t}</text>`;
const sym=(x,y,t,col,sz=16)=>`<text x="${x}" y="${y}" font-family="serif" font-size="${sz}" font-weight="bold" fill="${col}" text-anchor="middle">${t}</text>`;

// 6'-sialyllactose, reducing end at right; returns svg, anomer symbol coloured
const sl6=(x,y,an,col)=>L(x,y,x+64,y)+D(x,y,PUR)+C(x+32,y,YEL)+C(x+64,y,BLU)+sym(x+84,y+6,an,col,18);

// result strip at bottom of each panel
const strip=(x,y,now,need)=>`
<rect x="${x}" y="${y}" width="340" height="30" rx="5" fill="#FBEAEA"/>
${tx(x+12,y+21,'&#10007;',17,RED,'bold')}${tx(x+32,y+21,'Now',15,RED,'bold')}${tx(x+74,y+21,now,15,'#222')}
<rect x="${x}" y="${y+36}" width="340" height="30" rx="5" fill="#E7F2EA"/>
${tx(x+12,y+57,'&#10003;',17,GREEN,'bold')}${tx(x+32,y+57,'Needs',15,GREEN,'bold')}${tx(x+86,y+57,need,15,'#222')}`;

const panel=(x,y,n,col,q,sub,body,now,need)=>`
<rect x="${x}" y="${y}" width="364" height="290" rx="10" fill="${LGT}"/>
<circle cx="${x+26}" cy="${y+28}" r="15" fill="${col}"/>${tx(x+26,y+34,n,17,'white','bold','middle')}
${tx(x+50,y+26,q,17,'#222','bold')}
${tx(x+50,y+46,sub,14,col)}
<g transform="translate(${x},${y})">${body}</g>
${strip(x+12,y+212,now,need)}`;

// ---- panel bodies (coordinates relative to panel origin) ----
const b1=`
<path d="M70 82 L70 72 L288 72 L288 82" stroke="${GRY}" stroke-width="2" fill="none"/>
${tx(179,66,'same glycan, written two ways',13,GRY,'normal','middle')}
${sl6(40,118,'&#946;',NAVY)}${sl6(216,118,'&#945;',RED)}
${tx(72,154,'G28868ZC',14,NAVY,'bold','middle')}${tx(248,154,'G63717BV',14,RED,'bold','middle')}
${tx(72,174,'12 found',15,'#222','normal','middle')}${tx(248,174,'0 found',15,RED,'bold','middle')}`;

const b2=`
${sl6(130,92,'?',TEAL)}${tx(182,72,'G09675VB &#8212; ring not specified',13,TEAL,'normal','middle')}
<path d="M194 106 L194 120 M110 120 L278 120 M110 120 L110 132 M278 120 L278 132" stroke="${TEAL}" stroke-width="2" fill="none"/>
${sl6(56,152,'&#945;',GRY)}${sl6(226,152,'&#946;',GRY)}
${tx(110,184,'0',15,'#222','normal','middle')}${tx(278,184,'12',15,'#222','normal','middle')}
${tx(194,200,'the specific forms it stands for',13,GRY,'normal','middle')}`;

const b3=`
<rect x="24" y="74" width="142" height="100" rx="8" fill="#FFF7E0" stroke="${AMB}" stroke-width="2.5" stroke-dasharray="6,4"/>
${tx(95,94,'sialyl Lewis x',14,AMB,'bold','middle')}
${L(46,126,84,126)}${L(84,126,128,126)}${L(128,126,128,154)}
${D(46,126,PUR)}${C(84,126,YEL)}${Q(128,126,BLU)}${T(128,156,FUC,9)}
${L(128,126,206,126)}${C(206,126,MANG)}${L(206,126,250,126)}${Q(250,126,BLU)}${L(250,126,294,126)}${Q(294,126,BLU)}
${tx(250,160,'rest of the N-glycan',13,GRY,'normal','middle')}
${tx(182,194,'the epitope sits inside a larger structure',13,GRY,'normal','middle')}`;

const b4=`
${tx(40,74,'RCSB route',14,NAVY,'bold','start')}${tx(40,92,'10 entries',14,NAVY,'normal','start')}
${tx(324,74,'GlyGen route',14,RED,'bold','end')}${tx(324,92,'5 entries',14,RED,'normal','end')}
<circle cx="150" cy="134" r="52" fill="${NAVY}" fill-opacity="0.13" stroke="${NAVY}" stroke-width="2.5"/>
<circle cx="214" cy="134" r="42" fill="${RED}" fill-opacity="0.12" stroke="${RED}" stroke-width="2.5"/>
${tx(128,143,'7',26,NAVY,'bold','middle')}
${tx(186,141,'3',22,'#222','bold','middle')}
${tx(236,143,'2',26,RED,'bold','middle')}
${tx(182,200,'7 only via RCSB  &#183;  3 via both  &#183;  2 only via GlyGen',12,GRY,'normal','middle')}`;

const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 676">
<rect width="760" height="676" fill="white"/>
${tx(14,26,'Four ways a correct identifier still misses data',20,NAVY,'bold')}
${tx(14,48,'Each panel: the structures involved, what the search returns now, and what it would need to do',14,GRY)}
${panel(8,66,'1',NAVY,'&#8220;I want &#945; and &#946; alike&#8221;','two equally valid forms',b1,
  'the &#945; accession returns 0','search both and merge &#8594; 12')}
${panel(388,66,'2',TEAL,'&#8220;I did not determine that part&#8221;','a less specific form',b2,
  'the unspecified form returns 0','expand to its specific forms &#8594; 12')}
${panel(8,370,'3',AMB,'&#8220;every glycan with this epitope&#8221;','a part inside a whole',b3,
  '0 glycoproteins for the epitope','find structures that contain it')}
${panel(388,370,'4',RED,'&#8220;which answer is right?&#8221;','two resources disagree',b4,
  '10 or 5, depending on the route','reconcile both &#8594; 12 entries')}
</svg>`;
fs.writeFileSync('fig_dirs.svg',svg);
sharp(Buffer.from(svg),{density:420}).resize(1800,null,{fit:'inside'}).png().toFile('fig_dirs.png')
 .then(i=>console.log('fig_dirs.png',i.width+'x'+i.height));
