const fs=require('fs'), sharp=require('sharp');
const PUR='rgb(165,67,153)', YEL='rgb(255,212,0)', BLU='rgb(0,114,188)';
// Geometry/colours as returned by GlycanBuilder-MCP render_glycan; reducing-end symbol varies
function snfg(sym){
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 62">
<g stroke="black" stroke-width="2" fill="none">
 <line x1="145" y1="31" x2="93" y2="31"/><line x1="93" y1="31" x2="41" y2="31"/></g>
<circle cx="145" cy="31" r="12" fill="${BLU}" stroke="black" stroke-width="2"/>
<circle cx="93" cy="31" r="12" fill="${YEL}" stroke="black" stroke-width="2"/>
<polygon points="41,19 53,31 41,43 29,31" fill="${PUR}" stroke="black" stroke-width="2"/>
<g font-family="serif" font-size="16" fill="black" text-anchor="middle">
 <text x="67" y="55">&#945;6</text><text x="119" y="55">&#946;4</text>
 <text x="167" y="55" font-size="19" font-weight="bold">${sym}</text></g></svg>`;
}
const jobs=[['fam_b','&#946;'],['fam_a','&#945;'],['fam_x','?'],['fam_u','?']];
(async()=>{ for(const [n,s] of jobs){
  fs.writeFileSync(n+'.svg',snfg(s));
  await sharp(Buffer.from(snfg(s)),{density:600}).resize(1200,null,{fit:'inside'}).png().toFile(n+'.png');
  console.log(n+'.png');
}})();
