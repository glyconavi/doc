const fs=require('fs'), sharp=require('sharp');
// Geometry and colours exactly as returned by GlycanBuilder-MCP render_glycan
const PUR='rgb(165,67,153)', YEL='rgb(255,212,0)', BLU='rgb(0,114,188)';
function snfg(anomer, link){           // link = "6" or "3"
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 68">
<g stroke="black" stroke-width="2" fill="none">
  <line x1="145" y1="34" x2="93" y2="34"/><line x1="93" y1="34" x2="41" y2="34"/>
</g>
<circle cx="145" cy="34" r="13" fill="${BLU}" stroke="black" stroke-width="2"/>
<circle cx="93"  cy="34" r="13" fill="${YEL}" stroke="black" stroke-width="2"/>
<polygon points="41,21 54,34 41,47 28,34" fill="${PUR}" stroke="black" stroke-width="2"/>
<g font-family="serif" font-size="17" fill="black" text-anchor="middle">
  <text x="67" y="59">&#945;${link}</text>
  <text x="119" y="59">&#946;4</text>
  <text x="166" y="59">${anomer==='a'?'&#945;':'&#946;'}</text>
</g></svg>`;
}
const jobs=[['snfg_6sl_b','b','6'],['snfg_6sl_a','a','6'],['snfg_3sl_b','b','3']];
(async()=>{ for(const [n,a,l] of jobs){
  fs.writeFileSync(n+'.svg', snfg(a,l));
  await sharp(Buffer.from(snfg(a,l)),{density:600}).resize(1600,null,{fit:'inside'})
    .png().toFile(n+'.png');
  console.log(n+'.png');
}})();
