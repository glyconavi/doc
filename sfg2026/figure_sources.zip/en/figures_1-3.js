const fs=require('fs'), sharp=require('sharp');
const NAVY='#1C2088', RED='#B4121B', GRY='#6E6E6E', LGT='#EDEDF5', TEAL='#0E6E6E', AMB='#8A6100';
const PUR='#A54399', YEL='#FFD400', BLU='#0072BC', GRN='#00A651';
const SANS='Helvetica,Arial,sans-serif', MONO='DejaVu Sans Mono,Menlo,monospace';
const out=(n,svg,w)=>{require('fs').writeFileSync(n.replace(/\.png$/,'.svg'),svg);return sharp(Buffer.from(svg),{density:420}).resize(w,null,{fit:'inside'}).png().toFile(n).then(i=>console.log(n,i.width+'x'+i.height));};

// SNFG trisaccharide: Neu5Ac(a2-L)Gal(b1-4)Glc  drawn right-to-left (reducing end right)
const tri=(x,y,s,anom,link,hi)=>`<g transform="translate(${x},${y}) scale(${s})">
 <line x1="104" y1="0" x2="0" y2="0" stroke="#000" stroke-width="2.4"/>
 <circle cx="104" cy="0" r="13" fill="${BLU}" stroke="#000" stroke-width="2.4"/>
 <circle cx="52" cy="0" r="13" fill="${YEL}" stroke="#000" stroke-width="2.4"/>
 <polygon points="0,-13 13,0 0,13 -13,0" fill="${PUR}" stroke="#000" stroke-width="2.4"/>
 <text x="26" y="26" font-family="serif" font-size="16" text-anchor="middle">&#945;${link}</text>
 <text x="78" y="26" font-family="serif" font-size="16" text-anchor="middle">&#946;4</text>
 ${hi?`<circle cx="104" cy="0" r="22" fill="none" stroke="${hi}" stroke-width="3" stroke-dasharray="4,3"/>`:''}
 <text x="131" y="7" font-family="serif" font-size="23" font-weight="bold" fill="${hi||'#000'}">${anom}</text></g>`;

// ---------- FIG 1 : one name, two structures ----------
const F1=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 316">
<rect width="700" height="316" fill="white"/>
<rect x="196" y="6" width="308" height="46" rx="8" fill="white" stroke="${NAVY}" stroke-width="2.5"/>
<text x="350" y="36" font-family="${SANS}" font-size="23" font-weight="bold" fill="${NAVY}" text-anchor="middle">&#8220;6&#8242;-sialyllactose&#8221;</text>
<text x="350" y="72" font-family="${SANS}" font-size="16" fill="${GRY}" text-anchor="middle">the name says nothing about the reducing end</text>
<path d="M350 80 L350 96 L172 96 L172 116" stroke="${GRY}" stroke-width="2.5" fill="none"/>
<path d="M350 80 L350 96 L528 96 L528 116" stroke="${GRY}" stroke-width="2.5" fill="none"/>
<polygon points="164,114 180,114 172,130" fill="${GRY}"/><polygon points="520,114 536,114 528,130" fill="${GRY}"/>
<rect x="20" y="140" width="304" height="148" rx="8" fill="${LGT}"/>
<rect x="376" y="140" width="304" height="148" rx="8" fill="#FBECEC"/>
${tri(96,188,1.05,'&#946;','6',NAVY)}
${tri(452,188,1.05,'&#945;','6',RED)}
<text x="172" y="244" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}" text-anchor="middle">G28868ZC</text>
<text x="528" y="244" font-family="${SANS}" font-size="20" font-weight="bold" fill="${RED}" text-anchor="middle">G63717BV</text>
<text x="172" y="266" font-family="${SANS}" font-size="17" fill="#222" text-anchor="middle">12 PDB entries</text>
<text x="528" y="266" font-family="${SANS}" font-size="17" font-weight="bold" fill="${RED}" text-anchor="middle">0 PDB entries</text>
<text x="172" y="283" font-family="${MONO}" font-size="11" fill="${GRY}" text-anchor="middle">[a2122h-1b_1-5]&#8230;</text>
<text x="528" y="283" font-family="${MONO}" font-size="11" fill="${GRY}" text-anchor="middle">[a2122h-1a_1-5]&#8230;</text>
<text x="350" y="308" font-family="${SANS}" font-size="13" fill="${GRY}" text-anchor="middle">both are valid GlyTouCan registrations; in solution the two forms interconvert</text>
</svg>`;

// ---------- FIG 2 : why a search returns nothing ----------
const F2=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 740 338">
<rect width="740" height="338" fill="white"/>
<text x="18" y="26" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}">Why the search comes back empty</text>
<rect x="18" y="38" width="704" height="80" rx="8" fill="white" stroke="${NAVY}" stroke-width="2.5"/>
<text x="34" y="60" font-family="${SANS}" font-size="15" fill="${GRY}">you search for</text>
${tri(150,84,0.95,'&#945;','6',RED)}
<text x="470" y="80" font-family="${SANS}" font-size="16" fill="#222">&#945; at the reducing end</text>
<text x="470" y="104" font-family="${MONO}" font-size="12" fill="${GRY}">&#8230;[a2122h-1a_1-5]&#8230;</text>
<text x="370" y="140" font-family="${SANS}" font-size="15" fill="${GRY}" text-anchor="middle">every symbol must agree, including the last one</text>
<line x1="370" y1="118" x2="370" y2="150" stroke="${GRY}" stroke-width="2" stroke-dasharray="5,4"/>
<polygon points="362,148 378,148 370,162" fill="${GRY}"/>
${[0,1].map(k=>{const y=172+k*62; return `
<rect x="18" y="${y}" width="704" height="54" rx="7" fill="${LGT}"/>
${tri(150,y+28,0.95,'&#946;','6',NAVY)}
<text x="430" y="${y+26}" font-family="${SANS}" font-size="16" fill="#222">&#946; at the reducing end</text>
<text x="430" y="${y+46}" font-family="${MONO}" font-size="12" fill="${GRY}">&#8230;[a2122h-1b_1-5]&#8230;</text>
<text x="700" y="${y+34}" font-family="${SANS}" font-size="18" font-weight="bold" fill="${RED}" text-anchor="end">no match</text>`}).join('')}
<text x="18" y="310" font-family="${SANS}" font-size="20" font-weight="bold" fill="${RED}">Result: 0 &#8212; and it is returned as an answer, not as an error</text>
<text x="18" y="330" font-family="${SANS}" font-size="13" fill="${GRY}">the query is compared as a character string; no expansion or inference is applied</text>
</svg>`;

// ---------- FIG 3 : coverage of the 48 ----------
const F3=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 740 330">
<rect width="740" height="330" fill="white"/>
<text x="18" y="26" font-family="${SANS}" font-size="20" font-weight="bold" fill="${NAVY}">3&#8242;-sialyllactose: what each accession finds</text>
<text x="18" y="50" font-family="${SANS}" font-size="16" fill="#222">48 PDB entries contain this trisaccharide</text>
<rect x="18" y="62" width="704" height="24" rx="4" fill="#E4E4EA"/>
<text x="714" y="79" font-family="${SANS}" font-size="15" fill="${GRY}" text-anchor="end">all 48</text>
<rect x="18" y="104" width="${704*19/48}" height="36" rx="4" fill="${NAVY}"/>
<text x="32" y="128" font-family="${SANS}" font-size="18" font-weight="bold" fill="white">19 found</text>
<text x="${18+704*19/48+14}" y="122" font-family="${SANS}" font-size="16" fill="#222">search with the &#945; form &#8212; G92323ZH</text>
<text x="${18+704*19/48+14}" y="138" font-family="${SANS}" font-size="12" fill="${GRY}">29 entries are invisible to this query</text>
<rect x="${18+704*18/48}" y="152" width="${704*30/48}" height="36" rx="4" fill="${TEAL}"/>
<text x="${18+704*18/48+14}" y="176" font-family="${SANS}" font-size="18" font-weight="bold" fill="white">30 found</text>
<text x="${18+704*18/48-14}" y="170" font-family="${SANS}" font-size="16" fill="#222" text-anchor="end">&#946; form</text>
<text x="${18+704*18/48-14}" y="186" font-family="${SANS}" font-size="16" fill="#222" text-anchor="end">G91237TK</text>
<rect x="${18+704*18/48}" y="104" width="${704/48}" height="84" fill="none" stroke="${AMB}" stroke-width="2.5"/>
<text x="${18+704*18.5/48}" y="204" font-family="${SANS}" font-size="13" fill="${AMB}" text-anchor="middle">1 entry has both</text>
<rect x="18" y="226" width="704" height="38" rx="5" fill="none" stroke="${RED}" stroke-width="2.5" stroke-dasharray="7,5"/>
<text x="370" y="251" font-family="${SANS}" font-size="17" fill="${RED}" text-anchor="middle">no single accession covers the full set</text>
<text x="18" y="294" font-family="${SANS}" font-size="19" font-weight="bold" fill="#222">19 + 30 &#8722; 1 = 48 &#8212; only by searching twice and merging</text>
<text x="18" y="316" font-family="${SANS}" font-size="13" fill="${GRY}">neither accession is wrong; each is complete for the structure it specifies</text>
</svg>`;


(async()=>{ await out('fig_name.png',F1,1600); await out('fig_exact.png',F2,1700); await out('fig_venn.png',F3,1700); })();
