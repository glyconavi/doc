# Figure sources — SFG 2026 poster BM-16

Scripts that generate every figure on the poster, in English (`en/`) and
Japanese (`ja/`). Each script writes an SVG (editable source) and a PNG
(the image placed on the poster) to the current directory. The SVG files
produced by the scripts are included for convenience.

| Poster section | Figure | English | Japanese | Output |
|---|---|---|---|---|
| 1 | One name, two structures | `figures_1-3.js` | `figures_1-3_ja.js` | `fig_name` |
| 2 | Workflow (methods) | `figure_methods.js` | `figure_methods_ja.js` | `arch` |
| 4 | What each accession finds | `figures_1-3.js` | `figures_1-3_ja.js` | `fig_venn` |
| 5 | Why the search comes back empty | `figures_1-3.js` | `figures_1-3_ja.js` | `fig_exact` |
| 7 | Four ways a correct identifier still misses data | `figure_result5.js` | `figure_result5_ja.js` | `fig_dirs` |
| 4, 5 | SNFG of 3′- and 6′-sialyllactose | `snfg_sialyllactose.js` | (no text) | `snfg_*` |
| 6 | SNFG of the archetype family | `snfg_archetype_family.js` | (no text) | `fam_*` |

## Running

```
npm install sharp
node figures_1-3.js
```

Fonts used: Helvetica or Arial (English text), Noto Sans CJK JP (Japanese
text), DejaVu Sans Mono (WURCS strings), and a serif font for the SNFG
linkage labels. With the same fonts installed, the PNG files are identical
to those on the poster; with different fonts the layout is the same but
glyph shapes may differ.

## Notes

Glycan symbols follow the Symbol Nomenclature for Glycans (SNFG). They were
drawn for the poster following the SNFG guidelines, with the geometry and
colours modelled on GlycanBuilder-MCP output; they are not rendered by
GlycanBuilder-MCP itself.
